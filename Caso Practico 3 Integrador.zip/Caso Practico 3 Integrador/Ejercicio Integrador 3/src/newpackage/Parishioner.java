
package newpackage;

public class Parishioner {
    private String name;
    private String id;
    private double tithe;

    public Parishioner(String name, String id, double tithe) {
        this.name = name;
        this.id = id;
        this.tithe = tithe;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public double getTithe() {
        return tithe;
    }
}
    

