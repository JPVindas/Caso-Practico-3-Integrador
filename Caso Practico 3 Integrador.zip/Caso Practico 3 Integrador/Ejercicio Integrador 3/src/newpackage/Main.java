
package newpackage;



import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Se solicita el nombre de la iglesia y el pastor para el usuario
        System.out.print("Enter the church name: ");
        String churchName = scanner.nextLine();

        System.out.print("Enter the pastor's name: ");
        String pastorName = scanner.nextLine();

        ChurchManagement churchManagement = new ChurchManagement(churchName, pastorName);

        // Se solicita el numero de feligreses para el input
        System.out.print("Enter the number of parishioners: ");
        int numParishioners = Integer.parseInt(scanner.nextLine());

        // Poner la informacion para cada feligres y su diezmo
        for (int i = 0; i < numParishioners; i++) {
            System.out.print("Enter parishioner " + (i + 1) + "'s name: ");
            String parishionerName = scanner.nextLine();

            System.out.print("Enter parishioner " + (i + 1) + "'s ID: ");
            String parishionerId = scanner.nextLine();

            double parishionerTithe = churchManagement.getValidDoubleInput(scanner,
                    "Enter parishioner " + (i + 1) + "'s tithe: ");

            churchManagement.addParishioner(parishionerName, parishionerId, parishionerTithe);
        }

        // Se genera el reporte para y lo proyecta en la pantalla
        churchManagement.generateReport();
    }
}



    

