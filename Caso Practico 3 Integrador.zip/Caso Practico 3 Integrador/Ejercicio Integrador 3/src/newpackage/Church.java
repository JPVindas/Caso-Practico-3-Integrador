package newpackage;

import java.util.ArrayList;
import java.util.List;

public class Church {
    private String name;
    private String pastor;
    private List<Parishioner> parishioners;

    public Church(String name, String pastor) {
        this.name = name;
        this.pastor = pastor;
        this.parishioners = new ArrayList<>();
    }

    public void addParishioner(Parishioner parishioner) {
        parishioners.add(parishioner);
    }

    public double calculateTotalEarnings() {
        double totalEarnings = 0;
        for (Parishioner parishioner : parishioners) {
            totalEarnings += parishioner.getTithe();
        }
        return totalEarnings;
    }

    public double calculateInfrastructureTax() {
        return calculateTotalEarnings() * 0.09;
    }

    public double calculateComedorTax() {
        return calculateTotalEarnings() * 0.21;
    }

    public double calculatePastorEarnings() {
        return calculateTotalEarnings() * 0.7;
    }

    public List<Parishioner> getParishionersWithZeroTithe() {
        List<Parishioner> parishionersWithZeroTithe = new ArrayList<>();
        for (Parishioner parishioner : parishioners) {
            if (parishioner.getTithe() == 0) {
                parishionersWithZeroTithe.add(parishioner);
            }
        }
        return parishionersWithZeroTithe;
    }

    public List<Parishioner> getParishionersWithTitheOver100000() {
        List<Parishioner> parishionersWithTitheOver100000 = new ArrayList<>();
        for (Parishioner parishioner : parishioners) {
            if (parishioner.getTithe() > 100000) {
                parishionersWithTitheOver100000.add(parishioner);
            }
        }
        return parishionersWithTitheOver100000;
    }

    // Getters para el nombre de la iglesia y el del pastor 
    public String getName() {
        return name;
    }

    public String getPastor() {
        return pastor;
    }
}