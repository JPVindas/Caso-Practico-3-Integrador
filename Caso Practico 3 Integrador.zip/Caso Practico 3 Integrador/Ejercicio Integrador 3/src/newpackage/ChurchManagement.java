
package newpackage;

import java.util.List;
import java.util.Scanner;


public class ChurchManagement {
    private Church church;

    public ChurchManagement(String churchName, String pastorName) {
        church = new Church(churchName, pastorName);
    }

    public void addParishioner(String name, String id, double tithe) {
        Parishioner parishioner = new Parishioner(name, id, tithe);
        church.addParishioner(parishioner);
    }

    public void generateReport() {
        System.out.println("Church Information: " + church.getName());
        System.out.println("Pastor in Charge: " + church.getPastor());
        System.out.println("-----------------------------------------");
        System.out.println("Total Earnings of the Church: " + church.calculateTotalEarnings());
        System.out.println("Infrastructure Tax: " + church.calculateInfrastructureTax());
        System.out.println("dining room Tax: " + church.calculateComedorTax());
        System.out.println("Pastor's Earnings: " + church.calculatePastorEarnings());
        System.out.println("-----------------------------------------");
        System.out.println("Parishioners with Zero Tithe:");
        printParishioners(church.getParishionersWithZeroTithe());
        System.out.println("-----------------------------------------");
        System.out.println("Parishioners with Tithe over 100000:");
        printParishioners(church.getParishionersWithTitheOver100000());
    }

    private void printParishioners(List<Parishioner> parishioners) {
        for (Parishioner parishioner : parishioners) {
            System.out.println(parishioner.getName() + " - ID: " + parishioner.getId());
        }
    }

    double getValidDoubleInput(Scanner scanner, String message) {
        double value = 0;
        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.print(message);
                value = Double.parseDouble(scanner.nextLine());
                validInput = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid numeric value.");
            }
        }
        return value;
    }
}

    

